module Color.Switch {
    requires javafx.fxml;
    requires javafx.controls;
    requires  javafx.media;

    opens home;
}