package home;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TouchEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Ellipse;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class GamePlayController implements Initializable {
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		System.out.println("You just tapped SPACE!");
		TranslateTransition translateTransition = new TranslateTransition(Duration.millis(100), ball);
		ball.setTranslateY(ball.getTranslateY() + 10);
		translateTransition.setCycleCount(Animation.INDEFINITE);
		translateTransition.setAutoReverse(false);
		translateTransition.play();
	}
	
	@FXML private Pane myPane;
	@FXML private Pane PausePane;
	@FXML private Text gameplayScore;
	@FXML private ImageView PausePhoto;
	@FXML private Ellipse ball;

	@FXML
	public void PauseButton(MouseEvent event) throws IOException {
		String mediaPath = System.getProperty("user.dir") + "/src/Sounds/button.wav";
		MediaPlayer mediaPlayer = new MediaPlayer(new Media(new File(mediaPath).toURI().toString()));
		mediaPlayer.play();
		Stage primaryStage = new Stage();
		primaryStage.setTitle("Pause Menu");
		Parent root = FXMLLoader.load(getClass().getResource("/home/pause.fxml"));
		Scene scene = new Scene(root,300,600);
		primaryStage.setScene(scene);
		primaryStage.show();
		//(((Node) event.getSource())).getScene().getWindow().hide();
	}

	@FXML
	public void Resume(ActionEvent event) {
		String mediaPath = System.getProperty("user.dir") + "/src/Sounds/button.wav";
		MediaPlayer mediaPlayer = new MediaPlayer(new Media(new File(mediaPath).toURI().toString()));
		mediaPlayer.play();
		System.out.println("Resume");
		PausePane.getScene().getWindow().hide();
	}
	@FXML 
	public void Save(ActionEvent event) {
		String mediaPath = System.getProperty("user.dir") + "/src/Sounds/button.wav";
		MediaPlayer mediaPlayer = new MediaPlayer(new Media(new File(mediaPath).toURI().toString()));
		mediaPlayer.play();
		System.out.println("Save");
	}

	@FXML
	public void SaveAndExit(ActionEvent event) {
		String mediaPath = System.getProperty("user.dir") + "/src/Sounds/button.wav";
		MediaPlayer mediaPlayer = new MediaPlayer(new Media(new File(mediaPath).toURI().toString()));
		mediaPlayer.play();
		System.out.println("Save and Exit");
	}

	@FXML
	public void updateScore(MouseEvent event) {
		String mediaPath = System.getProperty("user.dir") + "/src/Sounds/jump.wav";
		MediaPlayer mediaPlayer = new MediaPlayer(new Media(new File(mediaPath).toURI().toString()));
		mediaPlayer.play();
		gameplayScore.setText(Integer.toString(Integer.parseInt(gameplayScore.getText()) + 1));
		ball.setTranslateY(ball.getTranslateY() - 90);
	}

	@FXML
	public void MainMenu(ActionEvent event) throws IOException{
		//get to main menu
		String mediaPath = System.getProperty("user.dir") + "/src/Sounds/button.wav";
		MediaPlayer mediaPlayer = new MediaPlayer(new Media(new File(mediaPath).toURI().toString()));
		mediaPlayer.play();
		(((Node) event.getSource())).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		primaryStage.setTitle("MAIN MENU");
		Parent root = FXMLLoader.load(getClass().getResource("/home/mainmenu.fxml"));
		Scene scene = new Scene(root,300,600);
		primaryStage.setScene(scene);
		primaryStage.show();

	}
}
